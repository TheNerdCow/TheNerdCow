start - Start this bot to have such a nice day :)
settings - Set your settings
quality - Set quality download
managing_banned - ADMIN ONLY I AM LAZY
add_banned - ADMIN ONLY I AM LAZY
shazam - Let me listen this audio
kill_dw - Kill current downloads💣
info - Show me something about this bot
reasons - WHY THIS BOT EXIST?
help - SOMEBODY HELP ME👨‍🚒
feedback - Have you questions?🙋‍♂️
donate - ONLY IF YOU ARE RICH🥺💸
graphs - BOT STATS📊