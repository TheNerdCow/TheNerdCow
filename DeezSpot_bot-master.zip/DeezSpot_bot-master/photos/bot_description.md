Hello guys welcome in @DeezSpot_bot⚡️.
DISCLAIMER:
                     1): DO NOT USE THIS BOT FOR YOUR OWN PURPOSE
                     2): I AM NOT RESPONSABLE FOR ANY ILLEGIT USAGE
                     3): The source code can be found here:
                                    a): https://github.com/An0nimia/DeezSpot_bot
                                    b): https://pypi.org/project/deezloader
                     4): ENJOY THE MUSIC ART🔥